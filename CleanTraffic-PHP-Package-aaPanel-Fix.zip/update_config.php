<?php
/**
 * CleanTraffic PHP Protection - Configuration Updater
 * Updates system configuration settings
 */

session_start();

header('Content-Type: application/json');
header('X-Robots-Tag: noindex, nofollow');

// Check authentication
if (!isset($_SESSION['admin_authenticated']) || $_SESSION['admin_authenticated'] !== true) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

$BASE_DIR = dirname($_SERVER['SCRIPT_FILENAME']);
$REDIRECT_URL_FILE = $BASE_DIR . '/redirect_url.txt';
$BOT_URL_FILE = $BASE_DIR . '/bot_url.txt';
$API_KEY_FILE = $BASE_DIR . '/api_key.txt';
$PASSWORD_FILE = $BASE_DIR . '/admin_password.txt';

$input = json_decode(file_get_contents('php://input'), true);

try {
    $updated = false;
    $errors = [];
    
    // Ensure directory is writable
    if (!is_writable($BASE_DIR)) {
        chmod($BASE_DIR, 0755);
    }
    
    // Update API key
    if (isset($input['apiKey']) && !empty($input['apiKey'])) {
        if (file_put_contents($API_KEY_FILE, trim($input['apiKey'])) !== false) {
            chmod($API_KEY_FILE, 0644);
            $updated = true;
        } else {
            $errors[] = "Cannot write API key file. Check file permissions (chmod 755 folder, 644 files)";
        }
    }
    
    // Update human redirect URL
    if (isset($input['humanUrl']) && !empty($input['humanUrl'])) {
        if (filter_var($input['humanUrl'], FILTER_VALIDATE_URL)) {
            if (file_put_contents($REDIRECT_URL_FILE, trim($input['humanUrl'])) !== false) {
                chmod($REDIRECT_URL_FILE, 0644);
                $updated = true;
            } else {
                $errors[] = "Cannot write redirect URL file. Check file permissions";
            }
        }
    }
    
    // Update bot redirect URL
    if (isset($input['botUrl']) && !empty($input['botUrl'])) {
        if (filter_var($input['botUrl'], FILTER_VALIDATE_URL)) {
            if (file_put_contents($BOT_URL_FILE, trim($input['botUrl'])) !== false) {
                chmod($BOT_URL_FILE, 0644);
                $updated = true;
            } else {
                $errors[] = "Cannot write bot URL file. Check file permissions";
            }
        }
    }
    
    // Update admin password
    if (isset($input['newPassword']) && !empty($input['newPassword'])) {
        $newPassword = trim($input['newPassword']);
        if (strlen($newPassword) >= 6) {
            if (file_put_contents($PASSWORD_FILE, $newPassword) !== false) {
                chmod($PASSWORD_FILE, 0644);
                $updated = true;
            } else {
                $errors[] = "Cannot write password file. Check file permissions";
            }
        }
    }
    
    if (!empty($errors)) {
        echo json_encode(['success' => false, 'error' => implode(', ', $errors), 'updated' => $updated]);
    } else {
        echo json_encode(['success' => true, 'updated' => $updated]);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>